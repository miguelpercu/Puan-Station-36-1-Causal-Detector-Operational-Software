SIMULATION SCRIPT – CONCEPTUAL VALIDATION ONLY
-----------------------------------------------
This folder contains a combined simulation of the 36+1 detector logic.

File:
    puan_combined_demo.py

Purpose:
    - To verify that the phase equations, dynamic frequency calculation,
      and asymmetry parameters produce the expected RMS (~0.7050).
    - To serve as a "digital twin" reference for educational purposes.

Important:
    This script is NOT intended for real‑time hardware control.
    For actual experiments, please use the operational scripts located
    in the parent directory:
        - puan_36ch_generator.py
        - puan_rms_monitor.py

Using this combined script with physical audio interfaces may result in
buffer underruns and unreliable timing.